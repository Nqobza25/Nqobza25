/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10166349.prog5121.poe.part3;

/**
 *
 * @author DISD3
 */
public class Login {
     public boolean usercomplexity(String User_name){
          if(User_name.contains("_") && User_name.length()<6){
        return true;
    }else {
        return false;
    
    }
      }
}
