package st10166349.prog5121.poe.part3;//package PROG5121_POE_Part3;//package PROG5121_POE_Part3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class St10166349_PROG5121_poe_Part3 {


    //fields
    int userChoice1;
    int userChoice2;
    static int userChoice3;
    int taskNum;
    int numOfTask = 0;
    int duration = 0;
    int autoTaskNumber = 0;
    String taskName, taskDescription, taskStatus, devFName, devLName, taskID;
    Scanner userInput = new Scanner(System.in);
    Scanner uInput = new Scanner(System.in);

    //ArrayLists (short term Storage)
    ArrayList<String> developers = new ArrayList<String>();
    ArrayList<String> taskNames = new ArrayList<String>();

    ArrayList<String> taskId = new ArrayList<String>();
    ArrayList<Integer> taskDuration = new ArrayList<Integer>();
    ArrayList<String> taskStat = new ArrayList<String>();

    ArrayList<String> taskDescriptions = new ArrayList<String>();
    //Arraylist(permanent Storage Base for all the task that have been added)
    ArrayList<String> developersFinal = new ArrayList<String>();
    ArrayList<String> taskNamesFinal = new ArrayList<String>();
    ArrayList<String> taskIdFinal = new ArrayList<String>();
    ArrayList<Integer> taskDurationFinal = new ArrayList<Integer>();
    ArrayList<String> taskStatFinal = new ArrayList<String>();
    ArrayList<String> taskDescriptionsFinal = new ArrayList<String>();

    //methods
    int terminate() {
        return 0;
    }

    void Menu() {

        System.out.println("===================================================");
        System.out.println("=======================Menu========================");
        System.out.println("===================================================");
        System.out.println("[1] \t Add tasks");
        System.out.println("[2] \t Show Report");
        System.out.println("[3] \t Exit");
        System.out.println("===================================================");
        System.out.print("Choose an option to continue : ");
        userChoice1 = userInput.nextInt();
        System.out.println("===================================================");

    }

    void StatusMenu() {
        System.out.println("===================================================");
        System.out.println("=================Task Status Menu==================");
        System.out.println("===================================================");
        System.out.println("[1] \t To DO");
        System.out.println("[2] \t Doing");
        System.out.println("[3] \t Done");
        System.out.println("===================================================");
        System.out.print("Selected the Task Status from the above menu: ");
        userChoice2 = userInput.nextInt(); //2
        //int sum2 = 4*4;
    }
    void ShowMenu() {

        System.out.println("===================================================");
        System.out.println("=======================Menu========================");
        System.out.println("===================================================");
        System.out.println("[1] \t Display Done Tasks");
        System.out.println("[2] \t Display Longest Task");
        System.out.println("[3] \t Search Task");
        System.out.println("[4] \t Delete Task");
        System.out.println("[5] \t Show Report");
        System.out.println("===================================================");
        System.out.print("Choose an option to continue : ");
        userChoice3 = userInput.nextInt();
        System.out.println("===================================================");
    }

    void Duration() {

        Scanner Nqo = new Scanner(System.in);
        //Duration
        System.out.println("Please enter N.o hours You would like to use:");
        duration = Nqo.nextInt();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Your entered  :" + duration + "hrs");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
    }

    void DevDetails() {
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println(":::::::::::::::::Developer Details:::::::::::::::::");
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.print("Developer Name : ");
        devFName = uInput.next();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.print("Developer Surname : ");
        devLName = uInput.next();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
    }

    void TaskID() {
        String div1, div3;
        int div2;
        div1 = (taskName.substring(0, 2)).concat(":");
        div2 = taskNum;
        div3 = devFName.substring(((devFName.length()) - 3));
        taskID = div1 + div2 + ":" + div3;

        /*taskID = taskName.substring(0, 1).concat(":") + taskNum +
        ":" + (devFirstName.substring((devFirstName.length() - 3))); //
        taskID = taskID.toUpperCase();*/
        //Debuggin reasons i'll print out the id
        System.out.println("[TaskID] : " + taskID.toUpperCase());
    }

    void TaskStatus() {
        StatusMenu();
        //choice = userInput.nextInt(); //2
        if (!((userChoice2 == 1) || (userChoice2 == 2) || (userChoice2 == 3))) {
            do {
                System.out.println("Invalid entry, please try again");
                StatusMenu();
            } while (!((userChoice2 == 1) || 
                    (userChoice2 == 2) || (userChoice2 == 3)));
        }
        if (((userChoice2 == 1) || (userChoice2 == 2) || (userChoice2 == 3))) {
            if (userChoice2 == 1) {
                taskStatus = "To Do";
                System.out.println("[Task Status]: " + taskStatus);
                System.out.println("======================="
                        + "============================");
                System.out.println("######################"
                        + "#############################");
                System.out.println("############ TasK"
                        + " Successfully Recorded ###########");
                System.out.println("############"
                        + "#######################################\n");
            }
            if (userChoice2 == 2) {
                taskStatus = "Doing";
                System.out.println("[Task Status]: " + taskStatus);
                System.out.println("===================================================");
                System.out.println("###################################################");
                System.out.println("############ TasK Successfully Recorded ###########");
                System.out.println("###################################################\n");
            }
            if (userChoice2 == 3) {
                taskStatus = "Done";
                System.out.println("[Task Status]: " + taskStatus);
                System.out.println("===================================================");
                System.out.println("###################################################");
                System.out.println("############ TasK Successfully Recorded ###########");
                System.out.println("###################################################\n");
            }
        }
    }

    void TaskDescription() {
        System.out.print("Task Description : ");
        taskDescription = uInput.nextLine();
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");

        String countTDetail = taskDescription.trim();
        //trim down excess whitespaces
        countTDetail.trim();
        //Removing the white spaces in between the strings
        String noSpace_CTD = countTDetail.replaceAll("\\s", "");
        // "\\s" -> represent a single line of space

        int taskDescription_len = noSpace_CTD.length();
        //System.out.println("Total character in Task Description : " + taskDescription_len);
        //validating
        // if (taskDescription_len < 50) {
        //     System.out.println("it works--- Please correct this output");
        // }
        if ((taskDescription_len > 50) || (taskDescription_len == 0)) {
            if (taskDescription_len > 50) {
                do {
                    System.out.println("Please enter"
                            + " a task description of less than 50 characters");
                    System.out.print("Task Description : ");
                    taskDescription = uInput.nextLine();
                    System.out.println("+++++++"
                            + "++++++++++++++++++++++++++++++++++++++++++++");
                    countTDetail = taskDescription.trim();
                    //trim down excess whitespaces
                    countTDetail.trim();
                    //Removing the white spaces in between the strings
                    noSpace_CTD = countTDetail.replaceAll(""
                            + "\\s", ""); 
// "\\s" -> represent a single line of space
                    taskDescription_len = noSpace_CTD.length();
                    //System.out.println
                    //("Total character in Task Description : " + taskDescription_len);
                    System.out.println("++++++++++"
                            + "+++++++++++++++++++++++++++++++++++++++++");
                } while ((taskDescription_len > 50));
            } else if (taskDescription_len == 0) {
                do {
                    System.out.println("Task Description cannot be empty, Try again");
                    System.out.print("Task Description : ");
                    taskDescription = uInput.nextLine();
                    System.out.println("++++++++++++++++"
                            + "+++++++++++++++++++++++++++++++++++");
                    countTDetail = taskDescription.trim();
                    //trim down excess whitespaces
                    countTDetail.trim();
                    //Removing the white spaces in between the strings
                    noSpace_CTD = countTDetail.replaceAll("\\s", ""); 
// "\\s" -> represent a single line of space
                    taskDescription_len = noSpace_CTD.length();
                    //System.out.println("Total character
                    //in Task Description : " + taskDescription_len);
                    System.out.println("+++++++++++++++++"
                            + "++++++++++++++++++++++++++++++++++");
                } while ((taskDescription_len == 0));
            }
        }

        if ((taskDescription_len > 0) && (taskDescription_len <= 50)) {
            System.out.println("Task captured successfully");
            //System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

    }


    void Validate(int lCounter) {
        if (!((userChoice1 == 3) || (userChoice1 == 2) || (userChoice1 == 1))) {
            do {
                System.out.println("Invalid input, Please try again:");
                Menu();
            } while (!((userChoice1 == 3) || (userChoice1 == 2) || (userChoice1 == 1)));
        }
        if ((userChoice1 == 3) || (userChoice1 == 2) || (userChoice1 == 1)) {
            //================Beginning of huge if====================
            if (userChoice1 == 1) {

                System.out.println("====================="
                        + "==============================\n");
                System.out.println("++++++++++++++++++++++"
                        + "+++++++++++++++++++++++++++++");
                //==============Beginning of huge for loop=======================
                for (int i = 0; i < lCounter; i++) {

                    System.out.println("+++++++++++++++++++"
                            + "++++++++++++++++++++++++++++++++");
                    System.out.print("Task Name : ");
                    taskName = userInput.next();
                    System.out.println("+++++++++++++++++++"
                            + "++++++++++++++++++++++++++++++++");
                    taskNum = autoTaskNumber;
                    //System.out.println("[Task Number] : "+autoTaskNumber); it works
                    System.out.println("+++++++++++++++++++"
                            + "++++++++++++++++++++++++++++++++");
                    // autogenTaskNum(numOfTask);
                    // numOfTask++;
                    //Task Description
                    TaskDescription();
                    //Dev Details
                    DevDetails();
                    //TaskID
                    System.out.println("###################"
                            + "################################");
                    TaskID();
                    System.out.println("##################"
                            + "#################################");
                    //Duration(Hours)
                    Duration();
                    //Task Status
                    TaskStatus();
                    autoTaskNumber++;

                    //populating the ArrayLists
                    developers.add((devFName + " " + devLName));
                    taskNames.add(taskName);
                    taskId.add(taskID);
                    taskDuration.add(duration);
                    taskStat.add(taskStatus);
                    taskDescriptions.add(taskDescription);
                }
            }//====================End of huge if===================
        }//==================End of for loop
    }
    {
        //Copying the content from temp arrayList to permanent arrayList
        developersFinal.addAll(developers);
        taskNamesFinal.addAll(taskNames);
        taskIdFinal.addAll(taskId);
        taskDurationFinal.addAll(taskDuration);
        taskStatFinal.addAll(taskStat);
        taskDescriptionsFinal.addAll(taskDescriptions);
    }

    void TaskDone(){
        int indexer = taskStat.indexOf("Done");
        System.out.println("[+]====================================================");
        System.out.println("||");
        System.out.println("[-] \t Developer Name : " + developers.get(indexer));
        System.out.println("[-] \t Task Name      : " + taskNames.get(indexer));
        System.out.println("[-] \t Task Duration  : "
                + "" + taskDuration.get(indexer) + " hours");
        System.out.println("[-] \t Task Status    : " + taskStat.get(indexer));
    }
    void LongestDuration(){
        //calling out the max method
        Integer maxHrs = Collections.max(taskDuration);
        //getting the index value of that max value
        int maxHrsIndex = taskDuration.indexOf(maxHrs);
        //printing out the task
        System.out.println("The task with the longest duration is : ");
        System.out.println("[+]=========================================[+]");
        System.out.println("\t Task Name     : " + taskNames.get(maxHrsIndex));
        System.out.println("\t Developer     : " + developers.get(maxHrsIndex));
        System.out.println("\t Task Duration : " + taskDuration.get(maxHrsIndex));
        System.out.println("\t Task Status   : " + taskStat.get(maxHrsIndex));
        System.out.println("[+]=========================================[+]");
    }
    void SearchTask(){
        Scanner searchInput = new Scanner(System.in);
        String searchString;
        int searchIndex;
        boolean isStringFound;
        System.out.print("Enter the Task Name : ");
        searchString = searchInput.nextLine();
        isStringFound = taskNames.contains(searchString);
        if (isStringFound == false) {
            System.out.println("There is no task "
                    + "found with the name : " + searchString);
        } else {
            searchIndex = taskNames.indexOf(searchString);
            System.out.println("[+]================="
                    + "===================================");
            System.out.println("|| Search Results"
                    + " for Taskname : " + searchString);
            System.out.println("[-] \t Developer Name : "
                    + developers.get(searchIndex));
            System.out.println("[-] \t Task Name      : "
                    + "" + taskNames.get(searchIndex));
            //System.out.println("[-] \t Task Duration  :
            //" + taskDuration.get(searchIndex) + " hours");
            System.out.println("[-] \t Task Status   "
                    + " : " + taskStat.get(searchIndex));
        }
    }
    void DeleteTask(){
        Scanner deleteInput = new Scanner(System.in);
        String deleteTaskName;
        int deleteIndex;
        boolean isTaskNameFound;

        System.out.print("Enter Taskname of the task you wish to delete : ");
        deleteTaskName = deleteInput.nextLine();
        isTaskNameFound = taskNames.contains(deleteTaskName);
        if (isTaskNameFound == false) {
            System.out.println("No task found with that TaskName !!");

        } else {
            deleteIndex = taskNames.indexOf(deleteTaskName);
            developers.remove(deleteIndex);
            taskNames.remove(deleteIndex);
            taskDuration.remove(deleteIndex);
            taskId.remove(deleteIndex);
            taskStat.remove(deleteIndex);

            System.out.println("Successfully deleted taskname : " + deleteTaskName);

        }
    }

    void PrintReport(){
        System.out.println("-=:Report:=-");
        for (int i = 0; i < taskNames.size(); i++) {
            System.out.println("[" + i + "]================="
                    + "=================================[+]");
            System.out.println("TaskName         : " + taskNames.get(i));
            System.out.println("TaskId           : " + taskId.get(i));
            System.out.println("Developer Name   : " + developers.get(i));
            System.out.println("Task Description : " + taskDescriptions.get(i));
            System.out.println("Task Status      : " + taskStat.get(i));
            System.out.println("[+]====================="
                    + "=============================[+]");
        }
    }
    public static void main(String[] args) {

        final int UsernamePassword_Uppecasel = 1;
//declaration of the final number for upper letter 1 upper case needed for password
        final int UsernamePassword_Lowercase = 3;
//declaration of the final number for lower case letter for 
//lower case as 3 lower case will be needed in the password
        final int UsernamePassword_SpecialCharacter_ = 1;
        final int num_digits = 1;//declaration for num digits
        //as 1 number or digit will be needed for 
        //password if you enter more than one it will give you not 
        //entered proper digits
        int upperCount = 0; //the integer for upper count 
        //is set to 0 for your characters
        int lowerCount = 0; //the integer for lower count
        //is set to 0 for your characters
        int digitCount = 0; //the integer for digit count
        //is set to 0 for your characters
        final int Users_password = 8;
        int letterCount = 0; // the integer for 
        //letter count is set to 0 for your characters
        int Pasword_SpecialCharacterset = 0;
        int Option1 = 1, Option2 = 2, Option3 = 3,
                Selection, TaskNum, Option, Selection_user,
                TaskNum2, ToDo = 0, Doing = 0, Done = 0,
                TaskNum1 = 0, LastLetter;
        String TaskName, User_TaskDescription;
        Scanner Nq = new Scanner(System.in); 
//my Scanner class for user userInput is set to Nq in declaration

        System.out.print("Hello please enter your new Username:");
//System.out print is  to print and greet the user to enter thier user_name

        String User_name = Nq.nextLine();
// User is prompted to enter their User name as a string

        System.out.print("Hello please enter your First_Name:");
        String Name = Nq.nextLine();
        System.out.print("Please enter your Last_Name:");
        String Last_name = Nq.nextLine();
        User_name.contains("_");

        if (User_name.length() <= 5 && User_name.contains("_")) {  // 
            //if statement is what i used to set the user names name 
            //lenght to be equals to 5 or less
            System.out.println("User_Name captured:\n" + User_name);
            //when the user enters the right amount of letters it will
            //say the name has be captured and shows the user name
            //this checks that has the user entered a underscore in the user

        } else if (User_name.length() >= 5 && User_name.contains("_"))
//otherwise if the user names name length is more than 5 letters
        {
            System.out.println("Username has no underscore"
                    + " .Could not Caputer User_name:");
// then the console will print to the user could not be able to capture user name
        } else {
            System.out.println("Sorry username could not"
                    + " be captured and has no underscore");
        }
        {  //this checks that has the user entered a underscore in the user

            {//these are curly braces to keep if statements in their 
                //own code block

                System.out.println("Hello user "
                        + "please enter your password:\n");
                
                //User is then asked to then enter their password
                String input = Nq.nextLine();
                //the user then is promted to enter the password

                int InputUser_Len = input.length();
                
                //inputLen is the declaration i made to promt the user 
                //to have a certain number of number characters
                //characthers in the for loop are 
                //then checked by the loop is the
                //uppercase is les then userInput len 
                //then it will be incremented by 1
                
                for (int i = 0; i < InputUser_Len; i++) {
                    char ch_userchar = input.charAt(i);
                    //this shows us that the user can userInput the 
                    //characters one at a time
                    if (Character.isUpperCase(ch_userchar)) {
                        upperCount++;
        //the characters for the uppercase are '
        //increased by 1 if they are less then the userInput length
                    } else if (Character.isLowerCase(ch_userchar)) {
                        lowerCount++;//if the 
                        //lower count is lower case it will be incremented by 1
                    } else if (Character.isDigit(ch_userchar)) {
                        digitCount++;//if the digit count is
                        //less than the userInput len then the digit will be  increased by 1
                    } else if (!Character.isLetterOrDigit(ch_userchar)) {
                        Pasword_SpecialCharacterset++;
                    }

                }

                if (upperCount >= UsernamePassword_Uppecasel 
                        && lowerCount >= UsernamePassword_Lowercase 
                        && num_digits >= digitCount && Pasword_SpecialCharacterset 
                        >= 1)//the if statement operator will compare 
                    //the upper case to the upper count, 
                    //the lower case to lower count and digits
                    //to digit count iff the are greater or equls
                    //to\nthe assigned operator then
                {
                    System.out.println("Password "
                            + "Successfully captured\n"
                            + "Welcome Great to See you: !!!"
                            + "\n" + Name + " " + Last_name);
//we get system out print of password is valid and a welcome for the user
                } else {
                    System.out.println("\n Login Failed!!!"
                            + "\nThe password did not "
                            + "have the following:");
//otherwise if the uppercase,lower case or digits are 
//not equal to the assigned operands then
                    if (upperCount < UsernamePassword_Uppecasel)//
                    {
                System.out.println("UpperLetters");
                
                //you will be told the password has no 1 upper case character

                    } else if (lowerCount < UsernamePassword_Lowercase) {
                        System.out.println("LowerCase");
                    // password has no 3 lower casse characters needed
                    }
                    if (digitCount < num_digits) {
                        System.out.println("Digits");
    // password has no 1 digit if there is more than 
    //2 digits the passord will be wrong one digits is needed
                    }
                    if (Pasword_SpecialCharacterset < 
                            UsernamePassword_SpecialCharacter_) {
                        System.out.println("Special "
                                + "character");
    //user is shown that they should enter a special character in the password
    
                    }
                    
                    System.out.print("1:"
                            + "upper case or 3:Lower case or digit:1");
//requirements for the password to be valid 3 lowwer case and 1 number or digit needed
                    if (Users_password >= 8) {
                        System.out.println("Sorry Your"
                                + " Password should be between 1 "
                                + "and 8 characters long.\n Please try again");

                    }

                }
            }
        }
        if (upperCount >= UsernamePassword_Uppecasel 
                && lowerCount >= UsernamePassword_Lowercase
                && num_digits >= digitCount && Pasword_SpecialCharacterset
                >= 1)
//the if statement operator will compare the
//upper case to the upper count, the lower case to lower
//count and digits to digit count iff 
            //the are greater or equls to\nthe assigned operator then
        {
            System.out.println("---------------------------------------------------");
        }
        System.out.println("Welcome to EasyKasnban");

        System.out.println("---------------------------------------------------");


        int counter = 0;
        Scanner counter2 = new Scanner(System.in);
        St10166349_PROG5121_poe_Part3 obj = new St10166349_PROG5121_poe_Part3();
        //The task ID will be generated upon runtime when
        //the user selects option 1 => to ADD TASKS
        do {
            obj.Menu(); //Prints the menu
            if (obj.userChoice1 == 1) {
                System.out.print("How many tasks do you wish to add ? ");
                counter = counter2.nextInt();
                obj.Validate(counter);
            }
            if (obj.userChoice1 == 2) {
                obj.ShowMenu();
                switch (userChoice3) {
                    case 1://Display Dev->tName->tDuration if(Done==true)
                        System.out.println("Printing Done Tasks");
                        //finding the tasks that are Completed
                        boolean tasksDone = obj.taskStat.contains("Done");
                        if (tasksDone == false) {
                            System.out.println("There aren't "
                                    + "ant task that have been completed yet!! ");
                        } else {
                            obj.TaskDone();
                            //prints out the tasks that are done
                        }
                        break;

                    case 2://Display Dev->Duration of the longestTask
                        obj.LongestDuration();//Getting the longest task
                        break;

                    case 3:
//Search for a task via -> TNumber and Display -> Dev->Tname->tStatus
                        obj.SearchTask();
                        break;

                    case 4:
//Delete a task via -> TNumber(Deleting the whole entry i guess)
                        obj.DeleteTask();
                        break;

                    case 5://Compiling a report 
                        //of all the details that have been captured
                        obj.PrintReport();
                }
            }
        } while (obj.userChoice1 != 3);
        if (obj.userChoice1 == 3) {
            System.out.println("Exiting program...");
            obj.terminate();
        }
    }
}


